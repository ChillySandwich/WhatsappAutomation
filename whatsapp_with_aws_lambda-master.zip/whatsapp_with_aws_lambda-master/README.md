# whatsapp with aws lambda
code for my [blog post](https://medium.com/better-programming/i-wrote-a-script-to-whatsapp-my-parents-every-morning-in-just-20-lines-of-python-code-5d203c3b36c1) on whatsapp messaging using AWS lambda.

![Technology stack used](tech_used.jpeg)
